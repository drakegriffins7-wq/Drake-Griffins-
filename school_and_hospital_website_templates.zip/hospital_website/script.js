// Replace this placeholder with the facility's official WhatsApp number (international digits only).
const CLINIC_WHATSAPP = "256700000000";
const menu = document.querySelector(".menu");
const nav = document.querySelector("#nav");
menu?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menu.setAttribute("aria-expanded", String(open));
});
nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open"); menu?.setAttribute("aria-expanded", "false");
}));
document.querySelector("#year").textContent = new Date().getFullYear();
const makeUrl = text => `https://wa.me/${CLINIC_WHATSAPP}?text=${encodeURIComponent(text)}`;
const wa = document.querySelector("#waLink");
wa.href = makeUrl("Hello CarePoint Medical Centre. I have a general enquiry.");
wa.addEventListener("click", e => { if (CLINIC_WHATSAPP === "256700000000") { e.preventDefault(); alert("Please replace CLINIC_WHATSAPP in script.js with the facility's official number."); } });
document.querySelector("#appointmentForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  if (!form.reportValidity()) return;
  if (CLINIC_WHATSAPP === "256700000000") { document.querySelector("#status").textContent = "Setup required: replace the demo WhatsApp number in script.js before launch."; return; }
  const d = new FormData(form);
  const message = `Hello CarePoint Medical Centre, I have a general enquiry.\\nName: ${d.get("name")}\\nPhone: ${d.get("phone")}\\nReason: ${d.get("reason")}\\nPreferred contact time: ${d.get("preferred") || "No preference"}\\nPlease contact me about this enquiry.`;
  document.querySelector("#status").textContent = "WhatsApp is opening. Review the message and tap Send there.";
  window.open(makeUrl(message), "_blank", "noopener,noreferrer");
});
