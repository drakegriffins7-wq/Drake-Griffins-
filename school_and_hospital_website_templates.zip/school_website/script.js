// Replace this placeholder with the school's real WhatsApp number (international digits only).
const SCHOOL_WHATSAPP = "256700000000";
const menu = document.querySelector(".menu");
const nav = document.querySelector("#nav");
menu?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menu.setAttribute("aria-expanded", String(open));
});
nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open"); menu?.setAttribute("aria-expanded", "false");
}));
document.querySelector("#year").textContent = new Date().getFullYear();
const wa = document.querySelector("#waLink");
const makeUrl = text => `https://wa.me/${SCHOOL_WHATSAPP}?text=${encodeURIComponent(text)}`;
wa.href = makeUrl("Hello Greenfield School. I would like to make an enquiry.");
wa.addEventListener("click", e => { if (SCHOOL_WHATSAPP === "256700000000") { e.preventDefault(); alert("Please replace SCHOOL_WHATSAPP in script.js with the school's real number."); } });
document.querySelector("#admissionForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  if (!form.reportValidity()) return;
  if (SCHOOL_WHATSAPP === "256700000000") { document.querySelector("#status").textContent = "Setup required: replace the demo WhatsApp number in script.js before launch."; return; }
  const d = new FormData(form);
  const message = `Hello Greenfield School, I would like to ask about admission.\\nParent/guardian: ${d.get("guardian")}\\nLearner: ${d.get("learner")}\\nClass: ${d.get("class")}\\nPhone: ${d.get("phone")}\\nQuestion: ${d.get("question") || "None"}`;
  document.querySelector("#status").textContent = "WhatsApp is opening. Review the message and tap Send there.";
  window.open(makeUrl(message), "_blank", "noopener,noreferrer");
});
