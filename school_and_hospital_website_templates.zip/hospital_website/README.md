# CarePoint Medical Centre website demo
A responsive healthcare facility website template with services, about, FAQs, contact details, and a WhatsApp enquiry form.

## Important before publishing
- This is a fictional demo brand. Replace the name, logo text, location, phone, hours, and all copy with verified facility information.
- In `script.js`, replace `CLINIC_WHATSAPP` with the facility's official WhatsApp number in international digits-only format.
- Only list services that the facility is licensed and equipped to provide. Have facility management approve the content.
- The form is for general enquiries only. Do not ask users to submit sensitive health information through this demo.
- The form does not store submissions or provide medical advice. It prepares a WhatsApp message for the visitor to review and send.
- Keep an emergency notice visible and update it to match local policy. Do not present this website as an emergency response service.

## Publish on GitHub Pages
Upload `index.html`, `style.css`, and `script.js` to the root of a GitHub repository. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/(root)`, and save.
