# Greenfield School website demo
A responsive school website template with admissions enquiry, school life, news, and WhatsApp contact.

## Before publishing
- Replace Greenfield School with the real school name and verify all content.
- Replace address, phone, and email placeholders in `index.html`.
- In `script.js`, replace `SCHOOL_WHATSAPP` with the official WhatsApp number in international digits-only format.
- Replace sample programme/news copy and stock photos with approved school content.
- Obtain permission before publishing identifiable student photos.

## Publish on GitHub Pages
Upload `index.html`, `style.css`, and `script.js` to the root of a GitHub repository. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/(root)`, and save.

## Limitation
The form does not store applications. It prepares a WhatsApp message for the visitor to review and send. A secure database/admin portal requires a backend.
